// Reading Progress Meter & Template Copy Engine

window.addEventListener('scroll', () => {
  const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
  const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
  const scrolled = (winScroll / height) * 100;
  document.getElementById('reading-progress-bar').style.width = scrolled + '%';

  // Highlight active TOC item
  const sections = document.querySelectorAll('.chapter-section');
  sections.forEach(sec => {
    const top = sec.offsetTop - 120;
    const bottom = top + sec.offsetHeight;
    if (winScroll >= top && winScroll < bottom) {
      document.querySelectorAll('.toc-link').forEach(link => link.classList.remove('active'));
      const activeLink = document.querySelector(`.toc-link[href="#${sec.id}"]`);
      if (activeLink) activeLink.classList.add('active');
    }
  });
});

// Copy Template Buttons
document.querySelectorAll('.btn-copy').forEach(btn => {
  btn.addEventListener('click', () => {
    const targetId = btn.getAttribute('data-target');
    const text = document.getElementById(targetId).innerText;
    navigator.clipboard.writeText(text).then(() => {
      const originalText = btn.innerText;
      btn.innerText = 'Copied!';
      setTimeout(() => btn.innerText = originalText, 1500);
    });
  });
});

// Copy All Templates
document.getElementById('btn-copy-vault').addEventListener('click', () => {
  const allTemplates = Array.from(document.querySelectorAll('pre')).map(p => p.innerText).join('\n\n---\n\n');
  navigator.clipboard.writeText(allTemplates).then(() => {
    const btn = document.getElementById('btn-copy-vault');
    btn.innerText = 'All Copied to Clipboard!';
    setTimeout(() => btn.innerText = 'Copy All Templates', 2000);
  });
});
